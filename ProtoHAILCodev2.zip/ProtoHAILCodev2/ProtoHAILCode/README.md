# Contrastive Learning from Positive and Unlabeled Data

## Preparation
Install the related package listed in requirements.txt

## Run experiments

Please refer to the README.md in cmc, infoGraph and simclr directories.