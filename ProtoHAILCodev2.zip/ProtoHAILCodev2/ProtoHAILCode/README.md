#  Adaptive vCPU Oversubscription in Cloud:  An  Active Prototypical Imitation Learning approach
 
## Preparation
Install the related package listed in requirements.txt
 
## Run experiments
 
run dataprocess_env.py to create the environment of airplane tickets
run prototypicalimitation_HITL.py to train an oversubscription policy